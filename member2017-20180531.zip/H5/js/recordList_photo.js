// 成长档案
httpUrl.danList=path+"/app/mbtrack/book/danList"; // 获取档案册档案页列表
user.bookId=GetQueryString("bookId");

winResize();
$(function () {
	init();
    $("#page-loader").addClass("hide");
}); 
function init() {
	danList_port();
    $("#children").change(function () {
         bookList_port();
    });
	
    $("body").on("click",".month img",function () {
        var data=JSON.parse($(this).attr("data-pic"));
        var openPhotoSwipe = function() {
            var pswpElement = document.querySelectorAll('.pswp')[0];
            var items = [];
            for(var i=0;i<data.length;i++){
                var obj={
                        src:httpUrl.path_img+data[i],
                        w:650,
                        h:910
                };
                items.push(obj);
            };
            var options = {    
                    history: false,
                    focus: false,
                    showAnimationDuration: 0,
                    hideAnimationDuration: 0
            };
            var gallery = new PhotoSwipe( pswpElement, PhotoSwipeUI_Default, items, options);
            gallery.init();
        };

        openPhotoSwipe();
    });  
};

// 获取档案册列表
function danList_port() {
    var data={
            bookId:user.bookId
        };
    var param={
            params:JSON.stringify(data)
    };
    initAjax(httpUrl.danList,param,danList_callback);
};
function danList_callback(res) {
    if(res.code==200 && res.data){
        var data={
                arr:JSON.parse(res.data),
                path_img:httpUrl.path_img
        };

        for(var i=0;i<data.arr.length;i++){
            for(var j=0;j<data.arr[i].monthDanVOList.length;j++){
                data.arr[i].monthDanVOList[j].picMd5List=JSON.stringify(data.arr[i].monthDanVOList[j].picMd5List);
            }
        };

        console.log(data);
        var html=template("swiper_script",data);
        $(".swiper-container").remove();
        $("body").append(html);

        var mySwiper = new Swiper('.swiper-container', {
                slidesPerView: 'auto',
                centeredSlides: !0,
                watchSlidesProgress: !0,
                onProgress: function (a) {
                    var b,c,d;
                    for (b = 0; b < a.slides.length; b++) c = a.slides[b],
                    d = c.progress,
                    scale = 1 - Math.min(Math.abs(0.2 * d), 1),
                    es = c.style,
                    es.opacity = 1 - Math.min(Math.abs(d / 2), 1),
                    es.webkitTransform = es.MsTransform = es.msTransform = es.MozTransform = es.OTransform = es.transform = 'translate3d(0px,0,' + - Math.abs(150 * d) + 'px)'
                },
                onSetTransition: function (a, b) {
                    for (var c = 0; c < a.slides.length; c++) es = a.slides[c].style,
                    es.webkitTransitionDuration = es.MsTransitionDuration = es.msTransitionDuration = es.MozTransitionDuration = es.OTransitionDuration = es.transitionDuration = b + 'ms'
                }
        });
    }else{
        console.log(res);
        // alert("系统故障，请稍候重试。。");
        // console.log('请求错误，返回code非200');
    }
};

function winResize() {
    var fs=$(window).width()/750*100;
    $("html").css("font-size",fs);
    $(window).resize(function () {
        var fs01=$(window).width()/750*100;
        $("html").css("font-size",fs01);
    });
}; 